#include "render/BodyDraw.h"
#include "io/EasyLog.h"

#include <raylib.h>
#include <raymath.h>
#include <rlgl.h>
#include <unordered_map>


static std::unordered_map<const BodyDef*, Model> s_cache;

void PreloadMesh(const BodyDef* def)
{
    if (!def || def->mesh_path.empty()) return;
    if (s_cache.count(def)) return;

    Model m = LoadModel(def->mesh_path.c_str());
    if (m.meshCount == 0) {
        LOG_WARN("BodyDraw: failed to load model: %s", def->mesh_path.c_str());
        UnloadModel(m);
        return;
    }
    s_cache[def] = m;
    LOG_DEBUG("BodyDraw: cached model for '%s'", def->name.c_str());
}

void UnloadAllMeshes()
{
    for (auto& [key, model] : s_cache)
        UnloadModel(model);
    s_cache.clear();
}


/// reuse code from Shopping Poroject
static Matrix QuatToMatrix(const float q[4])
{
    float x = q[0], y = q[1], z = q[2], w = q[3];
    return Matrix {
        1-2*(y*y+z*z),   2*(x*y-w*z),   2*(x*z+w*y), 0,
        2*(x*y+w*z), 1-2*(x*x+z*z),   2*(y*z-w*x), 0,
        2*(x*z-w*y),   2*(y*z+w*x), 1-2*(x*x+y*y), 0,
        0,             0,             0,   1
    };
}



static Color BodyColor(const BodyDef* def)
{
    if (!def) return GRAY;
    // Static bodies: muted gray
    if (def->mass == 0.0f) return { 100, 100, 110, 255 };
    // Dynamic: stable color from name hash
    unsigned h = 2166136261u;
    for (char c : def->name) h = (h ^ (unsigned char)c) * 16777619u;
    return {
        (unsigned char)(120 + (h        & 0x7F)),
        (unsigned char)(120 + ((h >> 8) & 0x7F)),
        (unsigned char)(120 + ((h >>16) & 0x7F)),
        255
    };
}



void DrawBodySnapshot(const BodySnapshot& body)
{
    Vector3 pos = { body.pos[0], body.pos[1], body.pos[2] };
    Matrix  rot = QuatToMatrix(body.rot);
    Color   col = BodyColor(body.def);

    

    // Full transform: rotate then translate
    Matrix transform = MatrixMultiply(rot, MatrixTranslate(pos.x, pos.y, pos.z));

    auto it = body.def ? s_cache.find(body.def) : s_cache.end();

    if (it != s_cache.end()) {
        Model& model = it->second;
        for (int m = 0; m < model.meshCount; ++m) {
            model.materials[model.meshMaterial[m]]
            .maps[MATERIAL_MAP_DIFFUSE].color = col;
            DrawMesh(model.meshes[m],
                     model.materials[model.meshMaterial[m]],
                     transform); 
        }
        // --- Pass 2: Wireframe Overlay ---
        // We use rlgl to apply the matrix and force wireframe mode
        static Material wire_mat = LoadMaterialDefault();
        wire_mat.maps[MATERIAL_MAP_DIFFUSE].color = {30, 30, 30, 130};

        rlPushMatrix();
        // Upload the transform matrix to the GPU
        rlMultMatrixf(MatrixToFloat(transform));

        rlEnableWireMode();
        for (int m = 0; m < model.meshCount; ++m)
        {
            // Draw with Identity because the matrix is already on the stack
            DrawMesh(model.meshes[m], wire_mat, MatrixIdentity());
        }
        rlDisableWireMode();
        rlPopMatrix();
    } else {
        // Fallback: unit cube when no mesh loaded
        DrawCube(pos, 0.3f, 0.3f, 0.3f, col);
        DrawCubeWires(pos, 0.3f, 0.3f, 0.3f, {40, 40, 40, 180});
    }
}
