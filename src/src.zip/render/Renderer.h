#pragma once
#include "core/Snapshot.h"
#include <raylib.h>



class Renderer {
public:
    void Init(int width, int height, const char* title, int target_fps);
    void Shutdown();

    bool ShouldClose() const;

    // Draw one frame. Reads snapshot, updates camera, calls BodyDraw + overlay.
    void DrawFrame(const WorldSnapshot& snapshot,
                   bool  nt_connected,
                   float sim_hz, float target_hz);

    bool m_cameraLocked = false;

private:
    Camera3D m_camera {};

    void DrawForceVectors(const WorldSnapshot& snapshot);
    void DrawArrow3D(Vector3 start, Vector3 end, Color color, float thickness);
};
