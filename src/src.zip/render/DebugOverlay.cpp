#include "render/DebugOverlay.h"
#include <raylib.h>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include "io/EasyLog.h"

static void DrawBar(int x, int y, int w, int h,
                    float fraction, Color fill, Color bg)
{
    DrawRectangle(x, y, w, h, bg);
    DrawRectangle(x, y, (int)(w * std::fabs(fraction)), h, fill);
    DrawRectangleLines(x, y, w, h, {80,80,80,200});
}

void DrawDebugOverlay(const WorldSnapshot& snapshot,
                      bool  nt_connected,
                      float sim_hz, float target_hz)
{
    constexpr int PAD   = 10;
    constexpr int LINE  = 18;
    constexpr int SMALL = 14;

    int y = PAD;
    char buf[128];

    // ── FPS + sim Hz ──────────────────────────────────────────────────────
    DrawFPS(PAD, y);
    y += LINE + 2;

    snprintf(buf, sizeof(buf), "Physics:  %.0f/%.0f Hz", sim_hz, target_hz);
    Color speed_color = ((target_hz - sim_hz > 5.0f) || (sim_hz - target_hz > 2.0f))
                        ? RED : LIGHTGRAY;
    DrawText(buf, PAD, y, SMALL, speed_color);
    y += LINE;

    snprintf(buf, sizeof(buf), "Physics Time: %.2f s", snapshot.sim_time);
    DrawText(buf, PAD, y, SMALL, LIGHTGRAY);
    y += LINE;

    snprintf(buf, sizeof(buf), "Wall Time: %.2f s", logger::elapsed() / 1000.0f);
    DrawText(buf, PAD, y, SMALL, LIGHTGRAY);
    y += LINE;

    snprintf(buf, sizeof(buf), "Time Loss: %.2f s",
             (logger::elapsed() / 1000.0f) - snapshot.sim_time);
    Color time_color = ((logger::elapsed() / 1000.0f) - snapshot.sim_time) > 2.9f
                       ? RED : LIGHTGRAY;
    DrawText(buf, PAD, y, SMALL, time_color);
    y += LINE;

    snprintf(buf, sizeof(buf), "Bodies: %d", (int)snapshot.bodies.size());
    DrawText(buf, PAD, y, SMALL, LIGHTGRAY);
    y += LINE + 4;

    // ── NT4 status ────────────────────────────────────────────────────────
    Color dot_col = nt_connected ? GREEN : RED;
    DrawCircle(PAD + 6, y + 6, 6, dot_col);
    DrawText(nt_connected ? "NT4  connected" : "NT4  disconnected",
             PAD + 18, y, SMALL, nt_connected ? GREEN : RED);
    y += LINE + 6;

    // ── Intake / Shooter HUD ──────────────────────────────────────────────
    if (snapshot.intake_max_capacity > 0)
    {
        // Piece counter with coloured pip squares
        snprintf(buf, sizeof(buf), "Intake: %d / %d",
                 snapshot.intake_held, snapshot.intake_max_capacity);
        DrawText(buf, PAD, y, SMALL, WHITE);

        // Draw small squares: filled = held, outline = empty
        int pip_x = PAD + 120;
        for (int i = 0; i < snapshot.intake_max_capacity; ++i)
        {
            Color c = (i < snapshot.intake_held) ? YELLOW : Color{80,80,80,200};
            DrawRectangle(pip_x + i * 14, y + 2, 10, 10, c);
            DrawRectangleLines(pip_x + i * 14, y + 2, 10, 10, LIGHTGRAY);
        }
        y += LINE + 2;
    }

    // ── Motor telemetry (robot body only) ─────────────────────────────────
    if (snapshot.robot_index < 0 ||
        snapshot.robot_index >= (int)snapshot.bodies.size()) return;

    const BodySnapshot& robot = snapshot.bodies[snapshot.robot_index];
    if (robot.motors.empty()) return;

    DrawText("Motors", PAD, y, SMALL, WHITE);
    y += LINE;

    for (int i = 0; i < (int)robot.motors.size(); ++i)
    {
        const MotorSnapshot& m = robot.motors[i];

        snprintf(buf, sizeof(buf), "[%d] %+6.1f rad/s", i, m.omega);
        DrawText(buf, PAD, y, SMALL, LIGHTGRAY);

        constexpr float FREE_SPEED = 608.0f;  // Kraken, display-only
        float frac = std::clamp(m.omega / FREE_SPEED, -1.0f, 1.0f);
        DrawBar(PAD + 150, y + 2, 80, LINE - 6,
                frac,
                m.slipping ? RED : SKYBLUE,
                {40, 40, 40, 200});

        if (m.slipping)
            DrawText("SLIP", PAD + 240, y, SMALL, RED);

        y += LINE;
    }

    DrawText("Force Vectors:", PAD, y, SMALL, WHITE);
    y += LINE;

    for (int i = 0; i < (int)robot.motors.size(); ++i)
    {
        const MotorSnapshot& m = robot.motors[i];
        snprintf(buf, sizeof(buf), "[%d] N:%.0f F:%.0f", i, m.normal_force, m.tractive_force);
        DrawText(buf, PAD, y, SMALL, LIGHTGRAY);
        y += LINE;
    }
}
