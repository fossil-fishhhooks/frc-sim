#include "core/SceneLoader.h"
#include "core/BodyLoader.h"
#include "io/EasyLog.h"

#include <nlohmann/json.hpp>
#include <fstream>
#include <filesystem>
#include <unordered_map>

using json = nlohmann::json;
namespace fs = std::filesystem;

std::vector<SpawnRequest> LoadScene(const std::string& scene_path,
                                    const MotorRegistry& motors)
{
    std::ifstream f(scene_path);
    if (!f.is_open()) {
        LOG_ERROR("SceneLoader: cannot open: %s", scene_path.c_str());
        return {};
    }

    json j;
    try { f >> j; }
    catch (const json::parse_error& e) {
        LOG_ERROR("SceneLoader: parse error: %s", e.what());
        return {};
    }

    fs::path scene_dir = fs::path(scene_path).parent_path();
    std::string scene_name = j.value("name", "unnamed");
    LOG_INFO("SceneLoader: loading scene '%s'", scene_name.c_str());

    std::vector<SpawnRequest> requests;

    if (!j.contains("bodies")) {
        LOG_WARN("SceneLoader: scene '%s' has no 'bodies' array", scene_name.c_str());
        return requests;
    }

    std::unordered_map<std::string, BodyDef> def_cache;

    for (const auto& entry : j["bodies"]) {
        if (!entry.contains("def")) {
            LOG_WARN("SceneLoader: body entry missing 'def' field, skipping");
            continue;
        }

        std::string def_rel  = entry["def"].get<std::string>();
        std::string def_path = (scene_dir / def_rel).string();

        if (!def_cache.count(def_path)) {
            auto maybe = LoadBodyDef(def_path, motors);
            if (!maybe) {
                LOG_WARN("SceneLoader: skipping body with failed def: %s", def_path.c_str());
                continue;
            }
            def_cache[def_path] = std::move(*maybe);
        }

        SpawnRequest req;
        req.def  = def_cache[def_path];
        req.role = entry.value("role", "");

        if (entry.contains("position")) {
            auto& p = entry["position"];
            req.position = { p[0].get<float>(), p[1].get<float>(), p[2].get<float>() };
        }
        if (entry.contains("orientation")) {
            auto& o = entry["orientation"];
            req.orientation = { o[0].get<float>(), o[1].get<float>(),
                o[2].get<float>(), o[3].get<float>() };
        }

        requests.push_back(std::move(req));
    }

    LOG_INFO("SceneLoader: %zu spawn requests loaded from '%s'",
             requests.size(), scene_name.c_str());
    return requests;
}
